WEITERGABE AN DRITTE NICHT ERLAUBT
SOLLTE MAN ETWAS ÄNDERN WOLLEN, SO IST EIN TICKET AUF UNSEREM DISCORD SERVER ZU ÖFFNEN


Falls du hilfe brauchst, oder etwas nicht funktioniert, kannst du dich gerne auf unserem Discord Server melden und ein Ticket öffnen.

Link: https://discord.gg/YkSq4yB8x3

DON'T GIVE THIS RESSOURCE TO SOMEONE ELSE
IF YOU WANT TO CHANGE SOMETHING, YOU HAVE TO JOIN OUR DISCORD SERVER AND ASK FOR PERMISSION

If you need help to stream your ressource or anything else, you can join our Discord Server and create a ticket.

https://discord.gg/YkSq4yB8x3



Coords for esx_shops:

vector3(374.92, 328.1, 103.57),
vector3(2555.09, 382.68, 108.62),
vector3(-3041.47, 585.63, 7.91),
vector3(-3244.15, 1002.02, 12.83),
vector3(547.69), 2668.97, 42.16),
vector3(1960.46, 3742.83, 32.34),
vector3(2676.94, 3282.1, 55.24),
vector3(1730.49, 6416.39, 35.04),
vector3(26.32, -1345.19, 29.5)